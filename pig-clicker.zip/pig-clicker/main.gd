extends Control

const MAX_TIER = 14
const FARM_MAX = 20
const SAVE_PATH = "user://save.json"

const TIER_NAMES = ["Поросятко", "Хрюша", "Кабанчик", "Бекон", "Шпик", "Сальник", "Борщовик", "Гетьман-Хряк", "Козак-Свин", "Свин-Танкіст", "Свин-Трактор", "Потужний Свин", "Святий Хряк", "Свин-Пілот", "Космо-Свин"]
const TIER_EMOJI = ["🐷", "🐖", "🐗", "🥓", "🍖", "🧈", "🍲", "👑", "⚔️", "🛡️", "🚜", "💪", "😇", "✈️", "🚀"]

const BOT_NAMES = ["👵 Баба Галя", "👴 Дід Мазай", "🔨 Коваль Микола", "🚜 Трактор", "🚁 Байрактар", "🛸 Прибульці-сальники"]
const BOT_RATE = [1.0, 8.0, 47.0, 260.0, 1400.0, 7800.0]
const BOT_COST = [60.0, 600.0, 6500.0, 75000.0, 900000.0, 12000000.0]

const MEMES = ["Потужно! 💪", "Хрюк!", "Сало — це сила", "Борщ чекає 🍲", "Слава салу!", "Дід схвалює 👴", "З цибулею 🧅", "Хрю-хрю-хрю", "Ну ти й хряк", "Ще шматочок!"]

# ---------- прогрес ----------
var salo: float = 0.0
var money: float = 0.0
var run_earned: float = 0.0
var lifetime: float = 0.0
var stars: int = 0
var rebirths: int = 0
var boss_level: int = 1
var farm: Array = []
var farm_cells: int = 12
var pigs_bought: int = 0
var sow_level: int = 0
var sow_timer: float = 0.0
var click_lvl: int = 0
var mult_lvl: int = 0
var price_lvl: int = 0
var fence_lvl: int = 0
var dog_lvl: int = 0
var auto_sell: bool = false
var bots: Array = [0, 0, 0, 0, 0, 0]
var clicks: int = 0

# ---------- рантайм ----------
var market_price: float = 1.0
var market_t: float = 25.0
var selected: int = -1
var croc_active: bool = false
var croc_hp: int = 0
var croc_time: float = 0.0
var croc_next: float = 60.0
var croc_dog_acc: float = 0.0
var boss_active: bool = false
var boss_hp: float = 0.0
var boss_time: float = 0.0
var rebirth_confirm: float = 0.0
var sound_on: bool = true
var ui_t: float = 0.0
var save_t: float = 0.0
var toast_t: float = 0.0
var current_page: int = 0

# ---------- ноди ----------
var snd: Dictionary = {}
var players: Array = []
var player_i: int = 0
var pages: Array = []
var tab_btns: Array = []
var cells: Array = []
var shop_btns: Dictionary = {}
var page_host: VBoxContainer
var float_layer: Control
var toast_lbl: Label
var lbl_money: Label
var lbl_sps: Label
var lbl_meta: Label
var sound_btn: Button
var croc_btn: Button
var lbl_click_info: Label
var pig_btn: Button
var sell_btn: Button
var lbl_fun: Label
var lbl_farm_info: Label
var buy_pig_btn: Button
var sow_btn: Button
var lbl_boss: Label
var boss_bar: ProgressBar
var boss_start_btn: Button
var boss_hit_btn: Button
var lbl_rebirth: Label
var rebirth_btn: Button


func _ready() -> void:
	randomize()
	var th = Theme.new()
	th.default_font_size = 28
	theme = th
	farm.resize(FARM_MAX)
	farm.fill(-1)
	build_sounds()
	build_ui()
	load_game()
	show_page(0)
	refresh_all()


# =====================================================================
#  ФОРМУЛИ
# =====================================================================
func star_mult() -> float:
	return 1.0 + 0.1 * stars


func click_power() -> float:
	return (1.0 + click_lvl) * pow(2.0, mult_lvl) * star_mult()


func pig_sps(t: int) -> float:
	return 0.2 * pow(2.6, t)


func farm_base() -> float:
	var s = 0.0
	for t in farm:
		if t >= 0:
			s += pig_sps(t)
	return s


func bot_base() -> float:
	var s = 0.0
	for i in 6:
		s += bots[i] * BOT_RATE[i]
	return s


func total_sps() -> float:
	return (farm_base() + bot_base()) * pow(2.0, mult_lvl) * star_mult()


func sale_price() -> float:
	return market_price * (1.0 + 0.2 * price_lvl)


func best_tier() -> int:
	var m = 0
	for t in farm:
		if t > m:
			m = t
	return m


func pig_cost() -> float:
	return 20.0 * pow(1.13, pigs_bought)


func cell_cost() -> float:
	return 300.0 * pow(4.0, farm_cells - 12)


func sow_cost() -> float:
	return 2500.0 * pow(2.2, sow_level)


func sow_interval() -> float:
	return maxf(8.0, 45.0 - 3.5 * sow_level)


func boss_max() -> float:
	return 400.0 * pow(2.2, boss_level - 1)


func croc_max_hp() -> int:
	return 6 + mini(30, rebirths * 2 + boss_level)


func rebirth_gain() -> int:
	return floori(sqrt(run_earned / 50000.0))


func first_empty() -> int:
	for i in farm_cells:
		if farm[i] < 0:
			return i
	return -1


func fmt(v: float) -> String:
	if v < 1000.0:
		if v < 10.0 and v != floor(v):
			return "%.1f" % v
		return str(int(v))
	var units = ["K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"]
	var i = -1
	while v >= 1000.0 and i < units.size() - 1:
		v /= 1000.0
		i += 1
	return "%.2f%s" % [v, units[i]]


# =====================================================================
#  ЗВУКИ (синтез, без файлів)
# =====================================================================
func make_sound(f0: float, f1: float, dur: float, kind: int, vol: float) -> AudioStreamWAV:
	var rate: float = 22050.0
	var n = int(rate * dur)
	var data = PackedByteArray()
	data.resize(n * 2)
	var phase: float = 0.0
	for i in n:
		var t: float = float(i) / float(n)
		var f: float = lerpf(f0, f1, t)
		phase += f / rate
		var s: float = 0.0
		match kind:
			0:
				s = sin(phase * TAU)
			1:
				s = 1.0 if fmod(phase, 1.0) < 0.5 else -1.0
			2:
				s = fmod(phase, 1.0) * 2.0 - 1.0
			3:
				s = (randf() * 2.0 - 1.0) * 0.7 + sin(phase * TAU) * 0.5
		var env: float = (1.0 - t) * minf(1.0, t * 20.0)
		var v = int(clampf(s * env * vol, -1.0, 1.0) * 32767.0)
		data.encode_s16(i * 2, v)
	var w = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = 22050
	w.stereo = false
	w.data = data
	return w


func build_sounds() -> void:
	snd["oink"] = make_sound(320.0, 110.0, 0.2, 2, 0.6)
	snd["squeal"] = make_sound(700.0, 1500.0, 0.18, 1, 0.35)
	snd["coin"] = make_sound(900.0, 1800.0, 0.12, 0, 0.6)
	snd["croc"] = make_sound(120.0, 40.0, 0.45, 3, 0.7)
	snd["boom"] = make_sound(160.0, 25.0, 0.5, 3, 0.8)
	snd["merge"] = make_sound(400.0, 1000.0, 0.22, 1, 0.35)
	snd["win"] = make_sound(500.0, 1500.0, 0.5, 0, 0.6)
	snd["fail"] = make_sound(300.0, 80.0, 0.5, 2, 0.5)
	snd["click"] = make_sound(600.0, 600.0, 0.05, 0, 0.5)
	for i in 8:
		var p = AudioStreamPlayer.new()
		add_child(p)
		players.append(p)


func play(sname: String, pitch: float = 1.0) -> void:
	if not sound_on:
		return
	var p: AudioStreamPlayer = players[player_i]
	player_i = (player_i + 1) % players.size()
	p.stream = snd[sname]
	p.pitch_scale = pitch
	p.play()


# =====================================================================
#  UI
# =====================================================================
func dark_panel() -> PanelContainer:
	var p = PanelContainer.new()
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0.6)
	sb.set_corner_radius_all(16)
	sb.set_content_margin_all(12)
	p.add_theme_stylebox_override("panel", sb)
	return p


func make_lbl(txt: String, size: int = 26) -> Label:
	var l = Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size", size)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func make_btn(txt: String, cb: Callable, h: float = 90.0) -> Button:
	var b = Button.new()
	b.text = txt
	b.custom_minimum_size = Vector2(0, h)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	return b


func make_scroll(pg: PanelContainer) -> VBoxContainer:
	var sc = ScrollContainer.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	pg.add_child(sc)
	var v = VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 10)
	sc.add_child(v)
	return v


func build_ui() -> void:
	var bg = VBoxContainer.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.add_theme_constant_override("separation", 0)
	add_child(bg)
	var blue = ColorRect.new()
	blue.color = Color("0057b7")
	blue.size_flags_vertical = Control.SIZE_EXPAND_FILL
	bg.add_child(blue)
	var yellow = ColorRect.new()
	yellow.color = Color("ffd700")
	yellow.size_flags_vertical = Control.SIZE_EXPAND_FILL
	bg.add_child(yellow)

	var margin = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 40)
	margin.add_theme_constant_override("margin_bottom", 10)
	add_child(margin)
	var root = VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	margin.add_child(root)

	# --- верхня панель ---
	var top = dark_panel()
	root.add_child(top)
	var tv = VBoxContainer.new()
	top.add_child(tv)
	var th_row = HBoxContainer.new()
	tv.add_child(th_row)
	lbl_money = make_lbl("", 32)
	th_row.add_child(lbl_money)
	sound_btn = make_btn("🔊", toggle_sound, 60.0)
	sound_btn.size_flags_horizontal = Control.SIZE_SHRINK_END
	sound_btn.custom_minimum_size = Vector2(80, 60)
	th_row.add_child(sound_btn)
	lbl_sps = make_lbl("", 24)
	tv.add_child(lbl_sps)
	lbl_meta = make_lbl("", 22)
	tv.add_child(lbl_meta)

	# --- крокодил ---
	croc_btn = make_btn("", hit_croc, 110.0)
	croc_btn.modulate = Color(1.0, 0.45, 0.45)
	croc_btn.visible = false
	root.add_child(croc_btn)

	# --- сторінки ---
	page_host = VBoxContainer.new()
	page_host.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(page_host)
	for i in 4:
		var pg = dark_panel()
		pg.size_flags_vertical = Control.SIZE_EXPAND_FILL
		page_host.add_child(pg)
		pages.append(pg)

	build_page_click()
	build_page_farm()
	build_page_shop()
	build_page_boss()

	# --- тост ---
	toast_lbl = make_lbl("", 26)
	toast_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_lbl.custom_minimum_size = Vector2(0, 64)
	toast_lbl.add_theme_color_override("font_outline_color", Color.BLACK)
	toast_lbl.add_theme_constant_override("outline_size", 8)
	root.add_child(toast_lbl)

	# --- вкладки ---
	var tabs = HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	root.add_child(tabs)
	var names = ["🐷 Клік", "🏠 Ферма", "🛒 Шоп", "👹 Бій"]
	for i in 4:
		var b = make_btn(names[i], show_page.bind(i), 100.0)
		b.toggle_mode = true
		b.add_theme_font_size_override("font_size", 26)
		tabs.add_child(b)
		tab_btns.append(b)

	# --- шар для плаваючих написів ---
	float_layer = Control.new()
	float_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	float_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(float_layer)


func build_page_click() -> void:
	var v = VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	pages[0].add_child(v)
	lbl_click_info = make_lbl("", 26)
	lbl_click_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(lbl_click_info)
	pig_btn = Button.new()
	pig_btn.flat = true
	pig_btn.focus_mode = Control.FOCUS_NONE
	pig_btn.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pig_btn.add_theme_font_size_override("font_size", 220)
	pig_btn.pressed.connect(on_pig_pressed)
	v.add_child(pig_btn)
	lbl_fun = make_lbl("Тапай по свині — з неї сиплеться сало!", 24)
	lbl_fun.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(lbl_fun)
	sell_btn = make_btn("", on_sell_pressed, 100.0)
	v.add_child(sell_btn)


func build_page_farm() -> void:
	var v = make_scroll(pages[1])
	lbl_farm_info = make_lbl("", 22)
	v.add_child(lbl_farm_info)
	var grid = GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(grid)
	for i in FARM_MAX:
		var c = Button.new()
		c.custom_minimum_size = Vector2(0, 150)
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		c.focus_mode = Control.FOCUS_NONE
		c.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		c.add_theme_font_size_override("font_size", 20)
		c.pressed.connect(on_cell.bind(i))
		grid.add_child(c)
		cells.append(c)
	buy_pig_btn = make_btn("", buy_pig, 100.0)
	v.add_child(buy_pig_btn)
	sow_btn = make_btn("", sow_buy, 110.0)
	sow_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(sow_btn)


func shop_button(id: String, parent: VBoxContainer) -> void:
	var b = Button.new()
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.custom_minimum_size = Vector2(0, 120)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(shop_buy.bind(id))
	parent.add_child(b)
	shop_btns[id] = b


func build_page_shop() -> void:
	var v = make_scroll(pages[2])
	v.add_child(make_lbl("— Прокачка —", 28))
	for id in ["click", "mult", "price", "autosell"]:
		shop_button(id, v)
	v.add_child(make_lbl("— Захист від крокодилів 🐊 —", 28))
	for id in ["fence", "dog"]:
		shop_button(id, v)
	v.add_child(make_lbl("— Боти (авто-сало) —", 28))
	for id in ["bot0", "bot1", "bot2", "bot3", "bot4", "bot5"]:
		shop_button(id, v)


func build_page_boss() -> void:
	var v = make_scroll(pages[3])
	lbl_boss = make_lbl("", 26)
	v.add_child(lbl_boss)
	boss_bar = ProgressBar.new()
	boss_bar.min_value = 0.0
	boss_bar.max_value = 1.0
	boss_bar.value = 1.0
	boss_bar.show_percentage = false
	boss_bar.custom_minimum_size = Vector2(0, 40)
	v.add_child(boss_bar)
	boss_start_btn = make_btn("⚔️ Почати бій з босом (30 с)", start_boss, 100.0)
	v.add_child(boss_start_btn)
	boss_hit_btn = make_btn("👊 БИЙ КРОКОДИЛА!!!", hit_boss, 240.0)
	boss_hit_btn.add_theme_font_size_override("font_size", 40)
	boss_hit_btn.modulate = Color(1.0, 0.6, 0.4)
	boss_hit_btn.visible = false
	v.add_child(boss_hit_btn)
	v.add_child(HSeparator.new())
	lbl_rebirth = make_lbl("", 26)
	v.add_child(lbl_rebirth)
	rebirth_btn = make_btn("", on_rebirth_pressed, 110.0)
	v.add_child(rebirth_btn)


func show_page(i: int) -> void:
	current_page = i
	for j in pages.size():
		pages[j].visible = (j == i)
		tab_btns[j].button_pressed = (j == i)
	refresh_all()


func toggle_sound() -> void:
	sound_on = not sound_on
	sound_btn.text = "🔊" if sound_on else "🔇"


func toast(txt: String) -> void:
	toast_lbl.text = txt
	toast_t = 3.5


func float_text(txt: String, pos: Vector2, col: Color = Color.WHITE, size: int = 36) -> void:
	if float_layer.get_child_count() > 30:
		return
	var l = Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	float_layer.add_child(l)
	l.position = pos - Vector2(40, 40)
	var tw = l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 170.0, 0.9)
	tw.tween_property(l, "modulate:a", 0.0, 0.9)
	tw.chain().tween_callback(l.queue_free)


# =====================================================================
#  КЛІК / ПРОДАЖ
# =====================================================================
func on_pig_pressed() -> void:
	var p = click_power()
	salo += p
	clicks += 1
	var pos = get_global_mouse_position()
	float_text("+" + fmt(p) + " 🥓", pos)
	if randf() < 0.12:
		float_text(MEMES.pick_random(), pos + Vector2(0, -90), Color.YELLOW, 42)
	play("oink", randf_range(0.8, 1.3))
	Input.vibrate_handheld(10)
	pig_btn.pivot_offset = pig_btn.size / 2.0
	pig_btn.scale = Vector2(1.12, 1.12)
	var tw = create_tween()
	tw.tween_property(pig_btn, "scale", Vector2.ONE, 0.12)


func on_sell_pressed() -> void:
	sell_salo(true)


func sell_salo(announce: bool = true) -> void:
	if salo <= 0.0:
		return
	var earned = salo * sale_price()
	salo = 0.0
	money += earned
	run_earned += earned
	lifetime += earned
	if announce:
		play("coin")
		float_text("+" + fmt(earned) + " ₴", get_global_mouse_position(), Color.GREEN, 44)
		refresh_all()


func new_market() -> void:
	market_t = randf_range(20.0, 35.0)
	market_price = randf_range(0.6, 1.8)
	if market_price > 1.4:
		toast("📈 Сало в ціні! ×%.2f — час продавати!" % market_price)
	elif market_price < 0.8:
		toast("📉 Сало дешевшає ×%.2f — тримай запаси" % market_price)


# =====================================================================
#  ФЕРМА
# =====================================================================
func on_cell(i: int) -> void:
	if i >= farm_cells:
		if i == farm_cells:
			var c = cell_cost()
			if money < c:
				toast("Клітинка коштує " + fmt(c) + " ₴ 💸")
				play("fail")
				return
			money -= c
			farm_cells += 1
			play("coin")
			toast("🔓 Нова клітинка відкрита!")
		else:
			toast("Спочатку відкрий попередню клітинку 🔒")
		return
	if selected == -1:
		if farm[i] >= 0:
			selected = i
			play("click")
		return
	var s = selected
	selected = -1
	if s == i:
		return
	if farm[i] < 0:
		farm[i] = farm[s]
		farm[s] = -1
		play("click")
		return
	var a: int = farm[s]
	var b: int = farm[i]
	if a == b:
		if a >= MAX_TIER:
			toast("Це вже Космо-Свин 🚀 Далі нікуди!")
			return
		farm[i] = a + 1
		farm[s] = -1
		play("merge")
		toast("✨ Злиття: " + TIER_NAMES[a + 1] + "!")
		return
	var lo = mini(a, b)
	var hi = maxi(a, b)
	var res = randi_range(lo, mini(hi + 1, MAX_TIER))
	farm[i] = res
	farm[s] = -1
	if res > hi:
		play("win")
		toast("🎰 ДЖЕКПОТ! Скрещування дало " + TIER_NAMES[res] + "!")
	else:
		play("merge", 0.8)
		toast("🎲 Скрещування: вийшов " + TIER_NAMES[res])


func buy_pig() -> void:
	var c = pig_cost()
	if money < c:
		toast("Не вистачає гривень 💸")
		play("fail")
		return
	var idx = first_empty()
	if idx < 0:
		toast("Ферма повна! Злий свиней або відкрий 🔒")
		return
	money -= c
	pigs_bought += 1
	farm[idx] = 0
	play("oink", randf_range(1.2, 1.6))
	refresh_all()


func sow_buy() -> void:
	if sow_level >= 10:
		toast("Свиноматка вже на максимумі 👑")
		return
	var c = sow_cost()
	if money < c:
		toast("Не вистачає гривень 💸")
		play("fail")
		return
	money -= c
	sow_level += 1
	sow_timer = 0.0
	play("win")
	toast("🐖👑 Свиноматка стала сильнішою!")
	refresh_all()


func sow_spawn() -> void:
	var idx = first_empty()
	if idx < 0:
		return
	farm[idx] = mini(5, floori(sow_level / 2.0))
	play("squeal", 1.5)
	toast("🐖👑 Свиноматка привела поросятко!")


# =====================================================================
#  ШОП
# =====================================================================
func shop_info(id: String) -> Dictionary:
	var d = {"t": "", "d": "", "cost": 0.0, "lvl": 0, "max": false}
	match id:
		"click":
			d["t"] = "👆 Сильніший тап (ур. %d)" % click_lvl
			d["d"] = "+1 сала за кожен тап"
			d["lvl"] = click_lvl
			d["cost"] = 15.0 * pow(1.4, click_lvl)
		"mult":
			d["t"] = "✖️ Подвоїти все (ур. %d)" % mult_lvl
			d["d"] = "×2 до тапів, свиней і ботів"
			d["lvl"] = mult_lvl
			d["cost"] = 3000.0 * pow(8.0, mult_lvl)
			d["max"] = mult_lvl >= 12
		"price":
			d["t"] = "💱 Вигідний ринок (ур. %d)" % price_lvl
			d["d"] = "+20% до ціни сала"
			d["lvl"] = price_lvl
			d["cost"] = 120.0 * pow(2.3, price_lvl)
			d["max"] = price_lvl >= 20
		"autosell":
			d["t"] = "🤝 Кооператив"
			d["d"] = "Сало продається само, без кнопки"
			d["lvl"] = 1 if auto_sell else 0
			d["cost"] = 4000.0
			d["max"] = auto_sell
		"fence":
			d["t"] = "🚧 Паркан (ур. %d)" % fence_lvl
			d["d"] = "Крокодил краде менше (зараз %d%%)" % int(maxf(5.0, 30.0 - 3.0 * fence_lvl))
			d["lvl"] = fence_lvl
			d["cost"] = 500.0 * pow(3.0, fence_lvl)
			d["max"] = fence_lvl >= 8
		"dog":
			d["t"] = "🐕 Пес-сторож (ур. %d)" % dog_lvl
			d["d"] = "Сам кусає крокодила (%.1f уд/с)" % (0.5 * dog_lvl)
			d["lvl"] = dog_lvl
			d["cost"] = 900.0 * pow(2.6, dog_lvl)
			d["max"] = dog_lvl >= 10
		_:
			var i = int(id.substr(3))
			d["t"] = BOT_NAMES[i] + " ×" + str(bots[i])
			d["d"] = "+" + fmt(BOT_RATE[i]) + " сала/с кожен"
			d["lvl"] = bots[i]
			d["cost"] = BOT_COST[i] * pow(1.15, bots[i])
	return d


func shop_buy(id: String) -> void:
	var d = shop_info(id)
	if d["max"]:
		toast("Вже максимум!")
		return
	if money < d["cost"]:
		toast("Не вистачає гривень 💸")
		play("fail")
		return
	money -= d["cost"]
	match id:
		"click":
			click_lvl += 1
		"mult":
			mult_lvl += 1
		"price":
			price_lvl += 1
		"autosell":
			auto_sell = true
		"fence":
			fence_lvl += 1
		"dog":
			dog_lvl += 1
		_:
			var i = int(id.substr(3))
			bots[i] += 1
	play("coin")
	refresh_all()


# =====================================================================
#  КРОКОДИЛ
# =====================================================================
func spawn_croc() -> void:
	croc_active = true
	croc_hp = croc_max_hp()
	croc_time = 10.0
	croc_dog_acc = 0.0
	play("croc")
	toast("🐊 КРОКОДИЛ краде гроші! ТАПАЙ ПО НЬОМУ!")


func hit_croc() -> void:
	if not croc_active:
		return
	croc_hp -= 1
	play("squeal", randf_range(0.8, 1.2))
	Input.vibrate_handheld(20)
	if croc_hp <= 0:
		croc_active = false
		var reward = maxf(50.0, total_sps() * 25.0)
		money += reward
		run_earned += reward
		lifetime += reward
		croc_next = randf_range(40.0, 80.0)
		toast("🐊 Крокодила відлупцьовано! Шкіра продана: +" + fmt(reward) + " ₴")
		play("win")
	refresh_croc()


func croc_steal() -> void:
	var pct = maxf(0.05, 0.30 - 0.03 * fence_lvl)
	var lost = money * pct
	money -= lost
	croc_active = false
	croc_next = randf_range(40.0, 80.0)
	play("croc")
	toast("🐊 Вкрав " + fmt(lost) + " ₴ (" + str(int(pct * 100.0)) + "%). Купи паркан і пса!")
	refresh_croc()


func refresh_croc() -> void:
	croc_btn.visible = croc_active
	if croc_active:
		croc_btn.text = "🐊 КРОКОДИЛ! ТАПАЙ!  HP %d   ⏱ %.1f с" % [croc_hp, maxf(0.0, croc_time)]


# =====================================================================
#  БОС / ПЕРЕРОДЖЕННЯ
# =====================================================================
func start_boss() -> void:
	if boss_active:
		return
	boss_active = true
	boss_hp = boss_max()
	boss_time = 30.0
	play("boom")
	toast("👹 БІЙ ПОЧАВСЯ! Свині й боти б'ються, а ти тапай!")
	refresh_all()


func hit_boss() -> void:
	if not boss_active:
		return
	boss_hp -= click_power() * 4.0
	play("oink", randf_range(0.7, 1.1))
	Input.vibrate_handheld(15)
	float_text("-" + fmt(click_power() * 4.0), get_global_mouse_position(), Color.ORANGE_RED, 44)
	check_boss()


func check_boss() -> void:
	if boss_hp <= 0.0:
		boss_active = false
		var reward = boss_max() * 1.5
		money += reward
		run_earned += reward
		lifetime += reward
		stars += 1
		boss_level += 1
		play("win")
		toast("🏆 БОС ПЕРЕМОЖЕНИЙ! +" + fmt(reward) + " ₴ і +1 ⭐")
		refresh_all()
	elif boss_time <= 0.0:
		boss_active = false
		play("fail")
		toast("😵 Час вийшов, бос втік. Спробуй ще!")
		refresh_all()


func on_rebirth_pressed() -> void:
	var g = rebirth_gain()
	if g <= 0:
		toast("Ще зарано — зароби більше за забіг")
		return
	if rebirth_confirm <= 0.0:
		rebirth_confirm = 4.0
		toast("Тапни ще раз: все скинеться, але ⭐ залишаться!")
		return
	stars += g
	rebirths += 1
	reset_run()
	play("win")
	toast("🔄 Переродження! +" + str(g) + " ⭐ Потужності")
	refresh_all()


func reset_run() -> void:
	salo = 0.0
	money = 0.0
	run_earned = 0.0
	farm.fill(-1)
	farm[0] = 0
	farm_cells = 12
	pigs_bought = 0
	sow_level = 0
	sow_timer = 0.0
	click_lvl = 0
	mult_lvl = 0
	price_lvl = 0
	fence_lvl = 0
	dog_lvl = 0
	auto_sell = false
	bots = [0, 0, 0, 0, 0, 0]
	selected = -1
	croc_active = false
	croc_next = 60.0
	boss_active = false
	rebirth_confirm = 0.0


# =====================================================================
#  ОНОВЛЕННЯ ЕКРАНУ
# =====================================================================
func refresh_all() -> void:
	lbl_money.text = "💰 " + fmt(money) + " ₴    🥓 " + fmt(salo)
	lbl_sps.text = "⚙️ " + fmt(total_sps()) + " сала/с    👆 " + fmt(click_power()) + "/тап"
	lbl_meta.text = "📈 Ринок ×%.2f   ⭐ %d (+%d%%)   🔄 %d   👹 Бос %d" % [market_price, stars, stars * 10, rebirths, boss_level]
	refresh_croc()
	match current_page:
		0:
			refresh_click()
		1:
			refresh_farm()
		2:
			refresh_shop()
		3:
			refresh_boss()


func refresh_click() -> void:
	pig_btn.text = TIER_EMOJI[best_tier()]
	lbl_click_info.text = "Сало: " + fmt(salo) + "  →  ≈ " + fmt(salo * sale_price()) + " ₴"
	sell_btn.text = "💵 Продати сало (+" + fmt(salo * sale_price()) + " ₴)"


func refresh_farm() -> void:
	lbl_farm_info.text = "Тапни 2 свині: однакові зливаються ⬆️, різні скрещуються 🎲 (результат між ними, іноді на +1). Свиня сама дає сало.\nЗ ферми: " + fmt(farm_base() * pow(2.0, mult_lvl) * star_mult()) + " сала/с"
	for i in FARM_MAX:
		var c: Button = cells[i]
		c.modulate = Color.WHITE
		if i >= farm_cells:
			c.text = "🔒\n" + (fmt(cell_cost()) + " ₴" if i == farm_cells else "")
		elif farm[i] < 0:
			c.text = "➕"
		else:
			var t: int = farm[i]
			c.text = "%s\n%s\n%s/с" % [TIER_EMOJI[t], TIER_NAMES[t], fmt(pig_sps(t) * pow(2.0, mult_lvl) * star_mult())]
		if i == selected:
			c.modulate = Color(1.0, 1.0, 0.4)
	buy_pig_btn.text = "🐷 Купити поросятко (" + fmt(pig_cost()) + " ₴)"
	if sow_level >= 10:
		sow_btn.text = "🐖👑 Свиноматка: МАКС (ур. 10)"
	elif sow_level == 0:
		sow_btn.text = "🐖👑 Купити свиноматку (" + fmt(sow_cost()) + " ₴) — сама приводить поросят"
	else:
		sow_btn.text = "🐖👑 Свиноматка ур. %d: поросятко кожні %.0f с. Покращити: %s ₴" % [sow_level, sow_interval(), fmt(sow_cost())]


func refresh_shop() -> void:
	for id in shop_btns:
		var d = shop_info(id)
		var b: Button = shop_btns[id]
		var price_txt = "МАКС" if d["max"] else fmt(d["cost"]) + " ₴"
		b.text = d["t"] + "\n" + d["d"] + "\n💰 " + price_txt
		if d["max"]:
			b.modulate = Color(0.7, 0.7, 0.7)
		elif money >= d["cost"]:
			b.modulate = Color(0.6, 1.0, 0.6)
		else:
			b.modulate = Color.WHITE


func refresh_boss() -> void:
	var mx = boss_max()
	boss_start_btn.visible = not boss_active
	boss_hit_btn.visible = boss_active
	if boss_active:
		boss_bar.value = clampf(boss_hp / mx, 0.0, 1.0)
		lbl_boss.text = "👹 Крокодил-бос ур. %d\nHP: %s / %s    ⏱ %.0f с" % [boss_level, fmt(maxf(0.0, boss_hp)), fmt(mx), maxf(0.0, boss_time)]
	else:
		boss_bar.value = 1.0
		lbl_boss.text = "👹 Крокодил-бос ур. %d\nHP: %s. Твої свині й боти б'ють %s/с, один тап = %s.\nНагорода: %s ₴ і +1 ⭐ (+10%% до всього назавжди)." % [boss_level, fmt(mx), fmt(total_sps() * 0.5), fmt(click_power() * 4.0), fmt(mx * 1.5)]
	var g = rebirth_gain()
	lbl_rebirth.text = "🔄 ПЕРЕРОДЖЕННЯ\nЗароблено за цей забіг: " + fmt(run_earned) + " ₴\nЗараз дасть: +" + str(g) + " ⭐ (кожна +10% до всього). Скидає гроші, ферму, шоп і ботів."
	rebirth_btn.text = ("🔄 Переродитись (+%d ⭐)" % g) if g > 0 else "🔄 Ще зарано"
	if rebirth_confirm > 0.0:
		rebirth_btn.text = "❗ Тапни ще раз для підтвердження"


# =====================================================================
#  ГОЛОВНИЙ ЦИКЛ
# =====================================================================
func _process(delta: float) -> void:
	salo += total_sps() * delta
	if auto_sell:
		sell_salo(false)

	market_t -= delta
	if market_t <= 0.0:
		new_market()

	if sow_level > 0:
		sow_timer += delta
		if sow_timer >= sow_interval():
			sow_timer = 0.0
			sow_spawn()

	if croc_active:
		croc_time -= delta
		if dog_lvl > 0:
			croc_dog_acc += delta * dog_lvl * 0.5
			while croc_dog_acc >= 1.0 and croc_active:
				croc_dog_acc -= 1.0
				hit_croc()
		if croc_active and croc_time <= 0.0:
			croc_steal()
	else:
		croc_next -= delta
		if croc_next <= 0.0:
			if money >= 100.0:
				spawn_croc()
			else:
				croc_next = 20.0

	if boss_active:
		boss_time -= delta
		boss_hp -= total_sps() * 0.5 * delta
		check_boss()

	if rebirth_confirm > 0.0:
		rebirth_confirm -= delta

	if toast_t > 0.0:
		toast_t -= delta
		if toast_t <= 0.0:
			toast_lbl.text = ""

	ui_t += delta
	if ui_t >= 0.2:
		ui_t = 0.0
		refresh_all()

	save_t += delta
	if save_t >= 10.0:
		save_t = 0.0
		save_game()


# =====================================================================
#  ЗБЕРЕЖЕННЯ
# =====================================================================
func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()


func save_game() -> void:
	var d = {
		"salo": salo, "money": money, "run_earned": run_earned, "lifetime": lifetime,
		"stars": stars, "rebirths": rebirths, "boss_level": boss_level,
		"farm": farm, "farm_cells": farm_cells, "pigs_bought": pigs_bought,
		"sow_level": sow_level, "click_lvl": click_lvl, "mult_lvl": mult_lvl,
		"price_lvl": price_lvl, "fence_lvl": fence_lvl, "dog_lvl": dog_lvl,
		"auto_sell": auto_sell, "bots": bots, "clicks": clicks,
		"time": Time.get_unix_time_from_system(),
	}
	var f = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))
		f.close()


func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		reset_run()
		return
	var f = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		reset_run()
		return
	var txt = f.get_as_text()
	f.close()
	var d = JSON.parse_string(txt)
	if typeof(d) != TYPE_DICTIONARY:
		reset_run()
		return
	salo = float(d.get("salo", 0.0))
	money = float(d.get("money", 0.0))
	run_earned = float(d.get("run_earned", 0.0))
	lifetime = float(d.get("lifetime", 0.0))
	stars = int(d.get("stars", 0))
	rebirths = int(d.get("rebirths", 0))
	boss_level = int(d.get("boss_level", 1))
	farm_cells = int(d.get("farm_cells", 12))
	pigs_bought = int(d.get("pigs_bought", 0))
	sow_level = int(d.get("sow_level", 0))
	click_lvl = int(d.get("click_lvl", 0))
	mult_lvl = int(d.get("mult_lvl", 0))
	price_lvl = int(d.get("price_lvl", 0))
	fence_lvl = int(d.get("fence_lvl", 0))
	dog_lvl = int(d.get("dog_lvl", 0))
	auto_sell = bool(d.get("auto_sell", false))
	clicks = int(d.get("clicks", 0))
	var fa = d.get("farm", [])
	for i in FARM_MAX:
		farm[i] = int(fa[i]) if i < fa.size() else -1
	var ba = d.get("bots", [])
	for i in 6:
		bots[i] = int(ba[i]) if i < ba.size() else 0
	var now = Time.get_unix_time_from_system()
	var away = clampf(now - float(d.get("time", now)), 0.0, 14400.0)
	if away > 60.0:
		var g = total_sps() * away * 0.5
		salo += g
		toast("😴 Поки тебе не було: +" + fmt(g) + " сала")
